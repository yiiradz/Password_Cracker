package password_crackers;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Yayira and Madeline
 */

public class pwd_Cracker {

}